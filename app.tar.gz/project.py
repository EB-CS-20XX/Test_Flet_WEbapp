from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal, get_args, Callable, Optional
 
import flet as ft
from flet.auth.oauth_provider import OAuthProvider
from flet.auth.authorization import Authorization

import asyncio
import aiohttp

import base64

class MyAuthorization(Authorization):
    def __init__(self, *args, **kwargs):
        super(MyAuthorization, self).__init__(*args, **kwargs)

    def _Authorization__get_default_headers(self):
        username = 'dMUAWUDrNnA_hSkWEclPuQ'
        encoded = base64.b64encode(f'{username}:'.encode('utf8')).decode('utf8')

        return {"User-Agent": f"Flet/0.7.4", "Authorization": f"Basic {encoded}", }

def arrow_color (score: Optional[bool], arrow: bool) -> str:
       match score, arrow:
              case True, True:
                     return '#f38f00'
              case False, False:
                     return '#2915ff'
              case _:
                     return '#444444'

def auth_redir (page: ft.Page, provider: OAuthProvider):
        def callback_click (_:ft.ControlEvent) -> None:
                page.login(provider, authorization = MyAuthorization)
        return callback_click

async def get_json(access_token: str, api_url: str):
        headers = {
                'Authorization': f'Bearer {access_token}'
        }
        request = aiohttp.request(
                method='get',
                url=f'{api_url}/new',
                headers=headers
        )

        async with request as resp:
                data = await resp.json()

        return data['data']['children']

def clear_page (page: ft.Page):
        while page.controls:
                page.controls.pop()

def log_out(page: ft.Page):
        def callback_out(_:ft.ControlEvent) -> None:
                clear_page(page)
                main(page)
        return callback_out


def main(page: ft.Page):
        base_auth_url = ft.TextField(label='Base Auth URL',value = "https://www.reddit.com")
        api_url = ft.TextField(label='Base API URL',value = "https://oauth.reddit.com")
        page.scroll = ft.ScrollMode.AUTO
        provider = OAuthProvider(
                client_id = 'dMUAWUDrNnA_hSkWEclPuQ', 
                client_secret='', 
                authorization_endpoint=f'{base_auth_url.value}/api/v1/authorize.compact?duration=permanent', 
                token_endpoint = f'{base_auth_url.value}/api/v1/access_token', 
                redirect_url = 'https://cs12222project-eb-cs-20xx.onrender.com/api/oauth/redirect', 
                user_scopes = ['identity','read']
        )

        def my_on_log():
                def callback_log (_:ft.ControlEvent) -> None:
                        #auth_tok = feed_page.auth.token.access_token
                        clear_page(page)
                        auth_tok = page.auth.token.access_token
                        p_tag = ft.Text (value = 'Loading...')
                        page.add (p_tag)
                        page.update()
                        contents = asyncio.run(get_json(auth_tok, api_url.value))
                        page.controls.pop()
                        post_list = ft.ListView(expand=1, spacing=10, padding=20)
                        logout_bttn = ft.ElevatedButton ('Log Out', on_click = log_out(page))
                        page.add (logout_bttn, post_list)
                        for item in contents:
                               post = item['data']
                               title, num_comments, author, subreddit, score, likes= post['title'], post['num_comments'], post['author'], post['subreddit'], post['score'], post['likes']
                               post_list.controls.append (ft.Text(value=title))
                               post_list.controls.append (ft.Text(value=f'Comments:{num_comments}, u/{author}, r/{subreddit}' ))
                               post_list.controls.append (
                                        ft.Row(
                                                spacing = 10,
                                                controls = [
                                                        ft.IconButton(
                                                                icon = ft.icons.ARROW_UPWARD,
                                                                icon_color = arrow_color(likes, True)
                                                        ),
                                                        ft.Text(
                                                                value = score
                                                        ),
                                                        ft.IconButton(
                                                                icon = ft.icons.ARROW_DOWNWARD,
                                                                icon_color = arrow_color(likes, False)
                                                        )
                                                ]
                                      )
                               )
                               post_list.controls.append (ft.Divider(height=9, thickness=3))
                               page.update()

                return callback_log
        
        login_button = ft.ElevatedButton ("Login", on_click = auth_redir(page, provider))
        page.on_login = my_on_log()
        page.add(base_auth_url, api_url, login_button)

ft.app(target=main, port=80, view=ft.WEB_BROWSER)
